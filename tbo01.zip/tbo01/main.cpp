#include <iostream>
#include "file_manager.h"
#include "movie.h"
#include "utils.h"

using namespace std;

int main(int argc, char * argv[]){


	FileManager fm("filmesCrop.txt");
	MovieLib movie_lib;


	if (fm.fetch_movies(movie_lib)) cout << "error";

	return 0;
}


