#pragma once

#include <sstream>
#include <string>
#include <vector>

using namespace std;

#define is_null(x, y, z) x == R"(\N)" ? z : y 

vector<string> _split(const string &str, const char &del){

        stringstream ss(str);

        string token;

        vector<string> r;

        while(getline(ss, token, del)){
                r.push_back(token);
        }

        return r;

}

