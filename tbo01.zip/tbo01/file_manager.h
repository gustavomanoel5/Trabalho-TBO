#pragma once

#include <fstream>
#include <string>
#include <vector>

#include "utils.h"
#include "movie.h"

#define prefix_size 2

using namespace std;

class FileManager{

	private:
		string filename;

	public:
		FileManager(string fname){
			filename = fname;
		}

	
		
		bool fetch_movies(MovieLib &lib){

        		ifstream file(filename);
        		if (!file.is_open()) return 1;

        		string line; bool ignore_first = true;

        		while(getline(file, line)){
					
						if (ignore_first){
							ignore_first = false;
							continue;
						}

                		vector<string> tokens = _split(line, '\t');
						tokens[0] = tokens[0].substr(prefix_size);

						if (lib.all_movies.size() == 0) {
							lib.starting_id = stoll(tokens[0]);
						}
						
						
						
                		lib.add_movie(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5], tokens[6], tokens[7], _split(tokens[8], ','));
        		}


        	return 0;

		};

	

};


vector<string> split(const string str, const char del);
